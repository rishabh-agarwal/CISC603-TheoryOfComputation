# Author
Rishabh Agarwal
CISC 603 - Project 3 Final Submission

# Instruction to run the program

1. Install ANTRL Plugin.
2. Open Toycompiler.g4 file
3. Right click on the rule name "Start"
4. You will be able to see ANTLR Preview and you will be able to test the grammar.