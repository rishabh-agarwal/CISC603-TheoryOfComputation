// Generated from /Users/Rishabh/workspace/toy-compiler/ToyCompiler.g4 by ANTLR 4.8
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link ToyCompilerParser}.
 */
public interface ToyCompilerListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link ToyCompilerParser#start}.
	 * @param ctx the parse tree
	 */
	void enterStart(ToyCompilerParser.StartContext ctx);
	/**
	 * Exit a parse tree produced by {@link ToyCompilerParser#start}.
	 * @param ctx the parse tree
	 */
	void exitStart(ToyCompilerParser.StartContext ctx);
}